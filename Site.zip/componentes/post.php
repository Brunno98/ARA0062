<?php

function estruturaPost($titulo, $corpo, $id, $usuario)
{
echo "
<div class='col-12 col-md-6 col-lg-4'>
  <div class='card mb-3'>
    <div class='card-body'>
      <input type='hidden' name='id' value='$id'>
      <h5 class='card-title'>$titulo</h5>
      <p class='card-text'>$corpo</p>

      <footer class='blockquote-footer text-right my-3'>
        <small class='text-muted'> by ~$usuario</small>
      </footer>
    </div>
      <div class='btn-group btn-block' role='group'>
        <a href='AlterarBlog.php?id=$id' class='btn btn-info'>Alterar</a>
        <a href='#' onclick='pergunta($id)' class='btn btn-danger'>Excluir</a>
      </div>
  </div>
</div>
";
}